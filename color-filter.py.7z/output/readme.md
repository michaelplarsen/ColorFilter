this folder contains images to be sent to react client
