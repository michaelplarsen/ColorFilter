this folder contains images sent from react client
