const fs = require("fs");
const { spawn } = require("child_process");
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const port = process.env.PORT ? process.env.PORT : 8000;

// middlewares
app.use(cors());

// home route
app.get("/", (req, res) => {
  res.json({
    desc: "suck my balls",
  });
});

app.get("/unlock", (req, res) => {
  const py = spawn("python", ["dooroperations.py", "unlock"]);

  res.json({
    desc: "unlocking door",
  });
});


app.get("/lock", (req, res) => {
  const py = spawn("python", ["dooroperations.py", "lock"]);

  res.json({
    desc: "locking door",
  });
});

app.post("/filter", (req, res) => {
  // Extracting Image from Client
  const body = req.body;
  // Removing Header from base64 string [header,image] = base64 image
  const base64Image = req.body.image.split(";base64,").pop();
  // Saving Image to Disk
  fs.writeFileSync("input/image.png", base64Image, { encoding: "base64" });

  // for extracting data from the callback inside py.stdout.on() in line 15
  var data2send;

  // creating a python child process
  const py = spawn("python", ["color-filter.py", body.color]);

  // when python prints data onto the console
  py.stdout.on("data", function (data) {
    data2send = data.toString();
  });

  // when the python child process ends
  py.on("close", () => {
    // Adding Heading and converting image to base64
    const image = `data:image/png;base64,${fs.readFileSync("output/image.png", {
      encoding: "base64",
    })}`;

    // sending image to client
    res.json({ image });
  });
});

app.listen(port, () => console.log("..."));
